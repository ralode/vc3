var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var routes = require('./routes/index');
var apiRoutes = require('./routes/api');
var apanelRoutes = require('./routes/apanel');

var app = express();
app.disable('x-powered-by');

// view engine setup
var swig = require('swig');
if (app.get('env')==='development') {
    swig.setDefaults({ cache: false });
}
app.engine('swig', swig.renderFile);

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'swig');


// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger('dev'));
app.use(bodyParser.json({limit:2048000, parameterLimit: 14000}));
app.use(bodyParser.urlencoded({extended: true, limit:2048000, parameterLimit: 14000}));
app.use(cookieParser());
app.use(express['static'](path.join(__dirname, 'public')));

// CORS заголовки
app.use(function(req, res, next){
    res.set({
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, GET, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'X-Requested-With, content-type, X-USER-COOKIE',
        'Access-Control-Max-Age':'86400'
    })
    next();
});

// Таймаут соединения
if (process.platform==='linux') {
    app.use(function(req, res, next){
        res.setTimeout(32000, function(){
            res.writeHead(304);
            res.end();
            res.emit('close');
        });
        next();
    });
}

app.use('/apanel', apanelRoutes);
app.use('/', routes);
app.use('/api', apiRoutes);

// Запросы OPTIONS
app.options('*', function(req, res){
    res.status(200).end();
});


// catch 404 and forward to error handler
app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handlers

app.use(function(err, req, res, next) {
    if (err.isApiError) {
        var data = {
            error: err.message,
            stack: app.get('env') === 'development' ? err.stack : '',
        };
        if (err.errorAccessDenied) data.errorAccessDenied = true;
        res.json(data);
    } else {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            error: app.get('env') === 'development' ? err : {}
        });
    }
});


module.exports = app;
