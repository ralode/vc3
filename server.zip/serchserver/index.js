var debug = require('debug')('konstructor_serv');
var app = require('./app.js');
var os = require('os');

var https = require('https');
var http = require('http');

if (os.platform()!=='win32') {
    // Secure serv
    var fs = require('fs');
    
	// Пути к сертификатам
    var privateKey  = fs.readFileSync('/home/node/cert/s5.key', 'utf8');
    var certificate = fs.readFileSync('/home/node/cert/s5.crt', 'utf8');
    var credentials = {
        key: privateKey, 
        cert: certificate,
    };
}

app.set('port', process.env.PORT || 8801);
app.set('port_secure', 8802);
app.set('secret_pass', '123456');

// Настройка приложения ВК
app.set('vk_app_id', '1111111'); // VK APP ID
app.set('vk_app_secret', 'secretsecretsecret'); // VK APP SECRET

// Настройка вк
var vkApi = require('vkApi_sdk');
vkApi.configure({
    id: app.get('vk_app_id'),
    secret: app.get('vk_app_secret'),
    scope: 'video,offline',
});

var server = app.listen(app.get('port'), function() {
    debug('Express server listening on port ' + server.address().port);
});
if (os.platform()!=='win32') {
    var serverSecure = https.createServer(credentials, app).listen(app.get('port_secure'));
	//var serverSecure = http.createServer(app).listen(app.get('port_secure'));
}