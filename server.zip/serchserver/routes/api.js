"use strict";

var express = require('express');
var router = express.Router();
var kset = require('kset_sdk');
var vkApi = require('vkApi_sdk');
var yandexVideoApi = require('yandexVideo_sdk');

var safeCentre = require('safe-centre');

var createApiError = safeCentre.createApiError;

var NodeCache = require("node-cache");
var importCache = new NodeCache();

// Авторизация на сервере
router.use(function(req, res, next) {
    // Разрешенные методы без авторизации
    if (req.path == '/version' || req.path=='/reload') {
        next();
        return;
    }
    safeCentre.auth(req, res, next);
});

// Поиск kset.kz
router.get('/kset', function(req, res, next) {
    if (typeof req.query.q === 'string' && req.query.q.length > 0) {
        kset.search({q: req.query.q}, function(err, data) {
            if (err) {
                next(createApiError(err));
            } else {
                res.json(data);
            }
        });
    } else {
        next(createApiError('Текст поиска не указан!'));
    }
});

// Поиск vk.com
router.get('/vk', function(req, res, next) {
    if (typeof req.query.q === 'string' && req.query.q.length > 0) {
        var longer = req.query.longer ? parseInt(req.query.longer) : 0;
        vkApi.search({q: req.query.q, longer: longer}, function(err, data) {
            if (res.connection!==null) {
                if (err) {
                    next(createApiError(err));
                } else {
                    res.json(data);
                }
            }
        }, req.currentUser);
    } else {
        next(createApiError('Текст поиска не указан!'));
    }
});

// Добавление видео ВК в свои видеозаписи
router.get('/vk/add', function(req, res, next) {
    if (typeof req.query.code === 'string' && req.query.code.length > 0) {
        vkApi.add({code: req.query.code}, function(err, data) {
            if (err) {
                next(createApiError(err));
            } else {
                res.json(data);
            }
        }, req.currentUser);
    } else {
        next(createApiError('Код видео не указан!'));
    }
});

var yandexTubeIdlist = {
    vkv: "vk.com",
    ytb: "youtube.com",
    rtb: "rutube.ru",
    mlr: "video.mail.ru",
    myv: "myvi.ru",
    kiv: "kiwi.kz",
    yan: "video.yandex.ru",
    meg: "megogo.net",
    ivi: "ivi.ru",
    sib: "video.sibnet.ru",
    kns: "kinostok.tv",
    vet: "veterok.tv",
    trb: "truba.com",
    //vaz: "video.az",
    vzl: "vzale.tv",
    ctv: "cinem.tv",
    //now.ru: "now.ru",
    met: "video.meta.ua",
};

// Поиск видео яндекс
router.get('/yandexVideo', function(req, res, next) {
    if (typeof req.query.q === 'string' && req.query.q.length > 0) {
        var longer = req.query.longer ? parseInt(req.query.longer) : 0;
        var text = req.query.q;
        if (req.query.tubeId && yandexTubeIdlist[req.query.tubeId]) {
            var site = yandexTubeIdlist[req.query.tubeId];
            if (site)
                text += ' site:'+site;
        }
        yandexVideoApi.search({q: text, ip: req.ip}, function(err, data) {
            if (err) {
                next(createApiError(err));
            } else {
                res.json(data); // json
            }
        });
    } else {
        next(createApiError('Текст поиска не указан!'));
    }
});

// Получение версии + блокировка скриптов
// Если res.cache начинается на ноль, или на букву, то это значит, что работа 
// скрипта для этого сайта заболкирована.
router.get('/version', function(req, res, next) {
    var userVersion = req.query.ver;
    var siteIp = req.query.siteIp;
    if (userVersion) {
        var ip = req.ip;
        var referer = req.get('referer');
        // ##!! Ниже проверка айпи и домена, на блек лист
        safeCentre.versionTrap({
            ip:ip, 
            referer:referer, 
            siteIp:siteIp, 
            userVersion:userVersion,
            hash: req.query.userQAuthHash,
        }, function(data){
            // {ver: '3.2.0026', ok: true, cache: 'D5Jifenk', message: 'У вас установлена актуальная версия скрипта.'}
			// ##!! ЗАГЛУШКА
			data.cache = '1'+data.cache;
            res.json(data);
        });
        
    } else
        next(createApiError('Текущая версия не указана!'));
});



// Обновление данных без перезагрузки потока
router.get('/reload', function(req, res, next) {
    var pass = req.query.pass;
    if (pass===req.app.get('secret_pass')) {
            safeCentre.reload(function(status, fromDb) {
                res.json({status: status, fromDb:fromDb});
            });
    } else
        next(createApiError('Доступ запрещен: это приватный мотод!'));
});

// Проверка
router.get('/check', function(req, res, next) {
    var data = {};
    var lic = req.currentUser.curr_license;
    var vk = req.currentUser.curr_vkontakte;
    if (lic) {
        // Date lic
        var date_end = parseInt(new Date(lic.date_end).getTime()/1000);
        var now = parseInt(new Date().getTime()/1000);
        data.date = Math.ceil(( date_end - now)/86400);
    } else
        data.date = 0;
    // Vk
    if (vk) {
        if (vk.use_public) 
            data.vk = 'public';
        else if (vk.vk_token) 
            data.vk = true;
        else
            data.vk = false;
    } else
        data.vk = false;
    // ##!!Заглушка для доменов, типа все принимаем
    data.domain = true;
    res.json(data); // {domain: true, date:202, vk:'public'}
});

// Импорт
router.get('/import', function(req, res, next) {
    var cacheId = req.currentUser.user; // admin
    importCache.get(cacheId, function(err, value) {
        if (!err && value[cacheId]) {
            res.json(value[cacheId]);
        } else 
            res.json({});
    });
});

// Экспорт
router.post('/export', function(req, res, next) {
    var cacheId = req.currentUser.user; // admin
    var exportData = req.body.export;
    if (exportData) {
        importCache.set(cacheId, exportData, function(err, success ) {
            res.json({success:success});
        });
    }
});

module.exports = router;
