var express = require('express');
var router = express.Router();
var safeCentre = require('safe-centre');
var vkApi = require('vkApi_sdk');
var md5 = require('MD5');
var myMysql = require('my-mysql');
var request = require('request');

router.get('/', function(req, res, next) {
    res.render('index.swig', {title:'API Server'});
});

router.get('/authorization', function(req, res, next) {
    var lic_id = req.query.lic_id;
    var hash = req.query.hash;
    
    var data = {
        title:'Авторизация вконтакте',
    };
    
    if (lic_id && hash) {
        var user = safeCentre.getUserByHash(hash);
        if (user && user.curr_license.lic_id==lic_id) {
            data.hash = hash;
            data.lic_id = lic_id;
            data.config = true;
        } else
            data.error = 'Лицензия не найдена!';
    } else {
        data.form = true;
    }
    res.render('authorization.swig', data);
});

router.post('/authorization', function(req, res, next) {
    var error = '';
    
    var email = req.body.email;
    var lic_key = req.body.lic_key;
    if (email && lic_key) {
        var hash = md5(lic_key);
        var user = safeCentre.getUserByHash(hash);
        if (user && user.email==email) {
            var lic_id = user.curr_license.lic_id;
            
            var url = 'http://'+req.hostname+':'+req.app.get('port')+'/authorization?lic_id='+lic_id+'&hash='+hash;
            res.redirect(url);
            return;
        } else
            error = 'Email или лицензионный ключ введено не верно...';
    } else
        error = 'Email или лицензионный ключ введено не верно';
    
    res.render('authorization.swig', {
        title:'Авторизация вконтакте',
        form: true,
        error: error,
    });
});

router.post('/authorization/save', function(req, res, next) {
    var hash = req.query.hash;
    var lic_id = req.query.lic_id;
    if (lic_id && hash) {
        var user = safeCentre.getUserByHash(hash);
        
        // Не менять демо
        if (lic_id=='151' && req.ip!=='89.252.37.148') {
            res.send('Аа, хитрый какой! А я хитрее :)');
            return;
        }
        
        if (user && user.curr_license.lic_id==lic_id) {
            if (req.body.use_public=='1') {
                myMysql.create(function(err, connection) {
                    connection.query('START TRANSACTION', function(err, rows) {
                        if (!err) {
                            connection.query('SELECT * FROM pref_vk WHERE lic_id=?', [lic_id], function(err, rows) {
                                if (!err) {
                                    if (rows && rows[0]) {
                                        var query = 'UPDATE pref_vk SET use_public=1 WHERE lic_id=?';
                                    } else {
                                        var query = 'INSERT INTO pref_vk (user_id, lic_id, use_public) VALUES ('+connection.escape(user.user_id)+', ?, 1)';
                                    }
                                    connection.query(query, [lic_id], function(err, rows) {
                                        if (!err) {
                                            connection.query('COMMIT', function(err, rows) {
                                                connection.release();
                                                if (!err) {
                                                    safeCentre.reload(function(){
                                                        res.send('Изменения успешно сохранены!');
                                                    });
                                                } else
                                                    next(new Error('Ошибка 4'));
                                            });
                                        } else {
                                            connection.release();
                                            next(new Error('Ошибка 3'));
                                        }
                                    });
                                } else {
                                    connection.release();
                                    next(new Error('Ошибка 2'));
                                }
                            });
                        } else {
                            connection.release();
                            next(new Error('Ошибка 1'));
                        }
                    });
                });
            } else {
                res.redirect('/authorization/vk?hash='+encodeURIComponent(hash)+'&lic_id='+encodeURIComponent(lic_id));
            }
        } else
            res.send('Ошибка 2');
    } else {
        res.send('Ошибка 1');
    }
});

router.get('/authorization/vk', function(req, res, next) {
    var code = req.query.code;
    var hash = req.query.hash;
    var lic_id = req.query.lic_id;
    var redirect_uri = 'http://'+req.hostname+':'+req.app.get('port')+'/authorization/vk?hash='+encodeURIComponent(hash)+'&lic_id='+encodeURIComponent(lic_id);
    
    if (req.query.error) {
        next(new Error(error));
        return;
    }
    
    // Не менять демо
    if (lic_id=='151' && req.ip!=='89.252.37.148') {
        res.send('Аа, хитрый какой! А я хитрее :)');
        return;
    }
    
    if (code) {
        // Тут проверку хеша
        var user = safeCentre.getUserByHash(hash);
        if (user && user.curr_license.lic_id==lic_id) {
            var url = vkApi.getTokenUrl(redirect_uri, code);
            request(url, function(err, response, body) {
                if (!err) {
                    //console.log('##Body', body, typeof body);
                    try {
                        var json = JSON.parse(body);
                        var token = json.access_token;
                        var uid = json.user_id;
                    } catch(e) {
                        next(new Error('Ошибка расбора json-token!'));
                        return;
                    }

                    if (token && uid) {
                        myMysql.create(function(err, connection) {
                            connection.query('START TRANSACTION', function(err, rows) {
                                if (!err) {
                                    connection.query('SELECT * FROM pref_vk WHERE lic_id=?', [lic_id], function(err, rows) {
                                        if (!err) {
                                            if (rows && rows[0]) {
                                                var query = 'UPDATE pref_vk SET use_public=0, vk_uid=?, vk_token=? WHERE lic_id=?';
                                            } else {
                                                var query = 'INSERT INTO pref_vk (vk_uid, vk_token, lic_id, use_public, user_id) VALUES (?, ?, ?, 0, '+connection.escape(user.user_id)+')';
                                            }
                                            connection.query(query, [uid, token, lic_id], function(err, rows) {
                                                if (!err) {
                                                    connection.query('COMMIT', function(err, rows) {
                                                        connection.release();
                                                        if (!err) {
                                                            safeCentre.reload(function(){
                                                                res.send('Изменения успешно сохранены!!');
                                                            });
                                                        } else
                                                            next(new Error('Ошибка 4'));
                                                    });
                                                } else {
                                                    connection.release();
                                                    next(new Error('Ошибка 3'));
                                                }
                                            });
                                        } else {
                                            connection.release();
                                            next(new Error('Ошибка 2'));
                                        }
                                    });
                                } else {
                                    connection.release();
                                    next(new Error('Ошибка 1'));
                                }
                            });
                        });
                    } else
                        next(new Error('Непонятная ошибка!'));

                } else {
                    next(new Error('Ошибка получения token!'));
                }
            });
        } else
            next(new Error('Невалидный хеш!'));
    } else {
        
        var url = vkApi.getOauthUrl(redirect_uri);
        res.redirect(url);
    }
});

module.exports = router;
