#!/usr/bin/env bash
cd /home/node/serchserver
NODE_ENV=production

mkdir -p logs
FILE1="./logs/$(date +'%Y-%m-%d_%H-%M-%S')_stdout.log"
FILE2="./logs/$(date +'%Y-%m-%d_%H-%M-%S')_stderr.log"

CMD="forever start -o $FILE1 -e $FILE2 index.js"
# Run command
if [ "$USER" == 'node' ]
then
	NODE_ENV=production $CMD
else
	runuser -l s4 -c "cd /home/node/serchserver && NODE_ENV=production cd $CMD"
fi

