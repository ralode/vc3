#!/usr/bin/env bash
cd /home/node/serchserver
forever stop index.js

