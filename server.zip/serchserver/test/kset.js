var fs = require('fs');
var util = require('util');
var kset = require('kset_sdk');
var url = require('url');

var searchResult = "";
var firstBlock = ''; // код первого найденного блока

var testPageHTML = '';

module.exports = {
    'Загрузка результатов поиска': function(test){
        searchResult = fs.readFileSync('./test/fixtures/kset_search_result.txt', {encoding:'utf-8'});
        test.equal(typeof searchResult, 'string');
        test.ok(searchResult.length>0);
        test.done();
    },
    'Проверка rexExp поиска': {
        'поиск блоков': function (test) {
            test.equal(typeof kset.searchRegExp, 'object');
            test.ok(util.isRegExp(kset.searchRegExp));
            var res = searchResult.match(kset.searchRegExp);
            test.ok(res);
            test.equal(res.length, 200); // Количество результатов поиска на странице
            firstBlock = res[0];
            test.done();
        },
        'расбор блока': {
            'проверка валидности блока': function (test) {
                test.equal(typeof firstBlock, 'string');
                test.ok(firstBlock.length>0);
                test.done();
            },
            'время видео': function (test) {
                var regExp = kset.patterns.duration;
                test.equal(typeof regExp, 'object');
                test.ok(util.isRegExp(regExp));
                var res = regExp.exec(firstBlock);
                test.equal(res[1], '2:01:00');
                test.done();
            },
            'название видео': function (test) {
                var regExp = kset.patterns.title;
                test.equal(typeof regExp, 'object');
                test.ok(util.isRegExp(regExp));
                var res = regExp.exec(firstBlock);
                test.equal(res[1], 'Амели (2001)');
                test.done();
            },
            'ссылка': function (test) {
                var regExp = kset.patterns.link;
                test.equal(typeof regExp, 'object');
                test.ok(util.isRegExp(regExp));
                var res = regExp.exec(firstBlock);
                test.equal(res[1], '/video/view/1772240?from=58308445');
                test.done();
            },
            'превью': function (test) {
                var regExp = kset.patterns.preview;
                test.equal(typeof regExp, 'object');
                test.ok(util.isRegExp(regExp));
                var res = regExp.exec(firstBlock);
                test.equal(res[1], 'http://videofarm08a.kset.kz/uploaded/29/229/1772240_200.jpeg');
                test.done();
            },
        },
    },
    'проверка получения кода': {
        'загрузка страницы': function(test) {
            test.equal(typeof kset.loadPageByLink, 'function');
            
            var link = '/video/view/2059206?from=58356793';
            kset.loadPageByLink(link, function(err, body){
                testPageHTML = body;
                test.equal(typeof body, 'string');
                test.ok(body.length>100);
                test.ifError(err);
                test.done();
            });
        },
        'получение кода iframe-src': function (test) {
            test.equal(typeof kset._parseIframe, 'function');

            var src = kset._parseIframe(testPageHTML);
            test.equal(typeof src, 'string');
            test.ok(src.length>0);
            test.equal(src, 'http://kset.kz/video_frame.php?id=2059206');
            var arr = url.parse(src);
            test.equal(arr.hostname, 'kset.kz');
            test.done();
        },
        'id to link': function (test) {
            test.equal(typeof kset._getLink, 'function');
            
            test.equal(kset._getLink(-555), false);
            test.equal(kset._getLink(0), false);
            test.equal(kset._getLink(666), '/video/view/666');
            test.done();
        },
        'получение src по id видео': function(test) {
            test.equal(typeof kset.srcById, 'function');
            
            var id = 58356793;
            kset.srcById(id, function(err, src){
                test.equal(typeof src, 'string');
                test.ok(src.length>0);
                test.equal(src, 'http://kset.kz/video_frame.php?id=58356793');
                test.done();
            });
        },
        '_getFullLink method': function(test) {
            var fullLink = kset._getFullLink(2059206);
            test.equals(typeof fullLink, 'string');
            test.equal(fullLink, 'http://kset.kz/video/view/2059206');
            test.done();
        },
        'проверка невалидного видео': function (test) {
            test.equal(typeof kset.checkById, 'function');
            // Не валидное видео
            kset.checkById (2059206000, function(err,status){
                test.ifError(err);
                test.equal(status, false);
                test.done();
            });
        },
        'проверка валидного видео': function (test) {
            test.equal(typeof kset.checkById, 'function');
            // Не валидное видео
            kset.checkById (2059206, function(err,status){
                test.ifError(err);
                test.equal(status, true);
                test.done();
            });
        },
    },
};

